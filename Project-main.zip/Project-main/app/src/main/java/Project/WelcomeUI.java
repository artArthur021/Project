package Project;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class WelcomeUI  {
    public WelcomeUI(Stage primaryStage) {
        // สร้างเมนูบาร์
        MenuBar menuBar = new MenuBar();

        // สร้างเมนูหลัก
        Menu name = new Menu("NameMenu");

        // สร้างรายการเมนู
        MenuItem Menu = new MenuItem("Menu");
        MenuItem exitItem = new MenuItem("exitIem ");


        // เพิ่ม ActionListener ให้เมนู Exit
        exitItem.setOnAction(e -> System.exit(0));
        Menu.setOnAction(e->new MenuUI(primaryStage));

        // เพิ่มรายการเมนูเข้าไปในเมนู File
        name.getItems().addAll(Menu, new SeparatorMenuItem(), exitItem);

        // เพิ่มเมนูหลักเข้าไปในแถบเมนู
        menuBar.getMenus().addAll(name);

        VBox root = new VBox(10);
        root.setStyle("-fx-padding: 20;");

        // สร้าง องค์ประกอบใน UI
        // ถ้าสำคัญให้ .setid("ตั้งชื่อ") เพื่อไว้ทำ Testcase ด้วย
        Label label = new Label("Welcome ");

        // จัดการ Layout

        root.getChildren().addAll(menuBar, label);
        // root.getChildren().addAll(fileMenu);
        Scene scene = new Scene(root, 400, 300);

        // ตั้งค่าหน้าต่างหลัก
        primaryStage.setTitle("Menu UI");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public Scene getScene() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getScene'");
    }
    
}

