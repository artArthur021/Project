package Project;

import java.util.ArrayList;
import java.util.List;


public class Cart {
    private List<String> items;
    private List<Integer> prices;

    public Cart() {
        items = new ArrayList<>();
        prices = new ArrayList<>();
    }

    public void addItem(String item, int price) {
        items.add(item);
        prices.add(price);
    }

    public int getTotal() {
        return prices.stream().mapToInt(Integer::intValue).sum();
    }

    public List<String> getItems() {
        return items;
    }

    public void clearCart() {
        items.clear();
        prices.clear();
    }
}


