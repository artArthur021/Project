package Project;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class RegisterUI {
    public RegisterUI(Stage primaryStage) {
        VBox root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-background-color: rgb(0, 0, 0);");

        Label titleLabel = new Label("Create a New Account");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: white;");
        
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");

        Button registerButton = new Button("Register");
        Button backButton = new Button("Back to Login");
        Label messageLabel = new Label();

        registerButton.setStyle("-fx-background-color: rgb(199, 131, 5); -fx-text-fill: white;");
        backButton.setStyle("-fx-background-color: rgb(199, 131, 5); -fx-text-fill: white;");

        registerButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            if (username.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Please fill in all fields.");
                messageLabel.setStyle("-fx-text-fill: yellow;");
                return;
            }

            if (Database.registerUser(username, password)) {
                messageLabel.setText("Registration successful! Redirecting...");
                messageLabel.setStyle("-fx-text-fill: lightgreen;");
                
                // ให้รอสักพักก่อนเปลี่ยนหน้า
                new Thread(() -> {
                    try {
                        Thread.sleep(1000);
                        javafx.application.Platform.runLater(() -> new LoginUI(primaryStage));
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }).start();
            } else {
                messageLabel.setText("Username already taken.");
                messageLabel.setStyle("-fx-text-fill: red;");
            }
        });

        backButton.setOnAction(e -> new LoginUI(primaryStage));

        root.getChildren().addAll(titleLabel, usernameField, passwordField, registerButton, backButton, messageLabel);
        primaryStage.setScene(new Scene(root, 350, 250));
        primaryStage.setTitle("Register");
        primaryStage.show();
    }
}
