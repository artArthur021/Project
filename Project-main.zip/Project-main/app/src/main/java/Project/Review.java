package Project;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Review {
    // ตัวแปร
    private MenuItem menuItem; // เมนูที่รีวิว
    private String reviewerName; // ชื่อผู้ที่รีวิว
    private int rating; // คะแนนรีวิว (1-5)
    private String comment; // ข้อความที่รีวิว

    // Constructor
    public Review(MenuItem menuItem, String reviewerName, int rating, String comment) {
        this.menuItem = menuItem;
        this.reviewerName = reviewerName;
        this.rating = rating;
        this.comment = comment;
    }

    // Getter and Setter สำหรับ menuItem
    public MenuItem getMenuItem() {
        return menuItem;
    }

    public void setMenuItem(MenuItem menuItem) {
        this.menuItem = menuItem;
    }

    // Getter and Setter สำหรับ reviewerName
    public String getReviewerName() {
        return reviewerName;
    }

    public void setReviewerName(String reviewerName) {
        this.reviewerName = reviewerName;
    }

    // Getter and Setter สำหรับ rating
    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        if (rating >= 1 && rating <= 5) { // ตรวจสอบคะแนนให้ถูกต้อง
            this.rating = rating;
        } else {
            System.out.println("คะแนนต้องอยู่ในช่วง 1-5");
        }
    }

    // Getter and Setter สำหรับ comment
    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    // Method ที่จะใช้ในการแสดงผลรีวิว
    public void displayReview() {
        System.out.println("Review for: " + menuItem.getText());
        System.out.println("Reviewer: " + reviewerName);
        System.out.println("Rating: " + rating + "/5");
        System.out.println("Comment: " + comment);
    }
}
