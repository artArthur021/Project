package Project;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MenuUI {
    public MenuUI(Stage primaryStage) {
        // สร้างเมนูบาร์
        MenuBar menuBar = new MenuBar();
        
        // สร้างเมนูหลัก
        Menu name = new Menu("NameMenu");
        Menu cart = new Menu("cart");
        Menu PayMent = new Menu("PayMent");
        Menu Review = new Menu("Review ");
        
        // สร้างรายการเมนู
        MenuItem Name = new MenuItem("Name");
        MenuItem Price = new MenuItem("Price");
        MenuItem exitItem = new MenuItem("exitIem ");
        //สร้างรายการ cart
        MenuItem cartItem = new MenuItem("Item");
        //สร้างรายการจ่ายเงิน
        MenuItem TotalAmount = new MenuItem("TotalAmount");
        MenuItem PaymentMethod = new MenuItem("PaymentMethod");
        //สร้างรายการ review
        MenuItem MenuReview = new MenuItem("MenuReview");
        MenuItem ReviewName = new MenuItem("ReviewName");
        MenuItem Rating = new MenuItem("Rating");
        MenuItem Comment = new MenuItem("Comment");
        
        
        // เพิ่ม ActionListener ให้เมนู Exit
        exitItem.setOnAction(e -> System.exit(0));
        
        // เพิ่มรายการเมนูเข้าไปในเมนู File
        name.getItems().addAll(Name, Price, new SeparatorMenuItem(), exitItem);
        cart.getItems().addAll(cartItem);
        PayMent.getItems().addAll(TotalAmount, PaymentMethod);
        Review.getItems().addAll(MenuReview, ReviewName , Rating, Comment);
        // เพิ่มเมนูหลักเข้าไปในแถบเมนู
        menuBar.getMenus().addAll(name, cart , PayMent , Review);
        
        
        // จัดการ Layout
        VBox root = new VBox(menuBar);

        // root.getChildren().addAll(fileMenu);
        Scene scene = new Scene(root, 400, 300);
        
        // ตั้งค่าหน้าต่างหลัก
        primaryStage.setTitle("Menu UI");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public class PayMent {
        private float totalAmount;
        private String paymentMethod;
    
        // Constructor
        public PayMent(float totalAmount, String paymentMethod) {
            this.totalAmount = totalAmount;
            this.paymentMethod = paymentMethod;
        }
    
        // Getter and Setter for totalAmount
        public float getTotalAmount() {
            return totalAmount;
        }
    
        public void setTotalAmount(float totalAmount) {
            this.totalAmount = totalAmount;
        }
    
        // Getter and Setter for paymentMethod
        public String getPaymentMethod() {
            return paymentMethod;
        }
    
        public void setPaymentMethod(String paymentMethod) {
            this.paymentMethod = paymentMethod;
        }
    
        // Method to process payment
        public void processPayment() {
            System.out.println("Processing payment of " + totalAmount + " using " + paymentMethod);
        }
    }
    public class Review {
        // ตัวแปร
        private MenuItem menuItem;  // เมนูที่รีวิว
        private String reviewerName; // ชื่อผู้ที่รีวิว
        private int rating;          // คะแนนรีวิว (1-5)
        private String comment;      // ข้อความที่รีวิว
        
        // Constructor
        public Review(MenuItem menuItem, String reviewerName, int rating, String comment) {
            this.menuItem = menuItem;
            this.reviewerName = reviewerName;
            this.rating = rating;
            this.comment = comment;
        }
        
        // Getter and Setter สำหรับ menuItem
        public MenuItem getMenuItem() {
            return menuItem;
        }
    
        public void setMenuItem(MenuItem menuItem) {
            this.menuItem = menuItem;
        }
        
        // Getter and Setter สำหรับ reviewerName
        public String getReviewerName() {
            return reviewerName;
        }
    
        public void setReviewerName(String reviewerName) {
            this.reviewerName = reviewerName;
        }
        
        // Getter and Setter สำหรับ rating
        public int getRating() {
            return rating;
        }
    
        public void setRating(int rating) {
            if (rating >= 1 && rating <= 5) {  // ตรวจสอบคะแนนให้ถูกต้อง
                this.rating = rating;
            } else {
                System.out.println("คะแนนต้องอยู่ในช่วง 1-5");
            }
        }
        
        // Getter and Setter สำหรับ comment
        public String getComment() {
            return comment;
        }
    
        public void setComment(String comment) {
            this.comment = comment;
        }
        
        // Method ที่จะใช้ในการแสดงผลรีวิว
        public void displayReview() {
            System.out.println("Review for: " + menuItem.getText());
            System.out.println("Reviewer: " + reviewerName);
            System.out.println("Rating: " + rating + "/5");
            System.out.println("Comment: " + comment);
        }
    }
}

