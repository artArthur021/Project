package Project;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;

public class MenuUI {
    private Cart cart;
    private ListView<String> cartListView;
    private Label totalLabel;
    private List<String> reviews = new ArrayList<>();

    public MenuUI(Stage primaryStage) {
        cart = new Cart();
        MenuBar menuBar = new MenuBar();
        Menu name = new Menu("NameMenu");
        Menu cartMenu = new Menu("Cart");
        Menu Review = new Menu("Review");

        MenuItem viewCart = new MenuItem("View Cart");
        viewCart.setOnAction(e -> showCart());
        cartMenu.getItems().add(viewCart);

        MenuItem reviewMenuItem = new MenuItem("Leave a Review");
        reviewMenuItem.setOnAction(e -> showReviewDialog());
        MenuItem viewReviewsMenuItem = new MenuItem("View Reviews");
        viewReviewsMenuItem.setOnAction(e -> showReviewHistory());

        Review.getItems().addAll(reviewMenuItem, viewReviewsMenuItem);

        menuBar.getMenus().addAll(name, cartMenu, Review);

        VBox root = new VBox(10);
        root.setStyle("-fx-padding: 20;");

        Label label = new Label("เมนูอาหาร");
        Button addItem1 = new Button("Add ส้มตำปูปลาร้า (50 บาท) to Cart");
        Button addItem2 = new Button("Add คอหมูย่าง (80 บาท) to Cart");
        Button addItem3 = new Button("Add ลาบ (60 บาท) to Cart");
        cartListView = new ListView<>();
        totalLabel = new Label("Total: 0 บาท");
        Button checkoutButton = new Button("Payment");
        Button backButton = new Button("Back to NameMenu");

        addItem1.setOnAction(e -> addToCart("ส้มตำปูปลาร้า", 50));
        addItem2.setOnAction(e -> addToCart("คอหมูย่าง", 80));
        addItem3.setOnAction(e -> addToCart("ลาบ", 60));
        checkoutButton.setOnAction(e -> checkout());
        backButton.setOnAction(e -> goToNameMenu(primaryStage));

        root.getChildren().addAll(menuBar, label, addItem1, addItem2, addItem3, cartListView, totalLabel,
                checkoutButton, backButton);

        Scene scene = new Scene(root, 400, 400);
        primaryStage.setTitle("Menu UI");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addToCart(String item, int price) {
        cart.addItem(item, price);
        updateCartDisplay();
    }

    private void updateCartDisplay() {
        cartListView.getItems().setAll(cart.getItems());
        totalLabel.setText("Total: " + cart.getTotal() + " บาท");
    }

    private void showCart() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Cart");
        alert.setHeaderText("Items in Cart");
        alert.setContentText(String.join("\n", cart.getItems()) + "\n\nTotal: " + cart.getTotal() + " บาท");
        alert.showAndWait();
    }

    private void checkout() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Payment");
        dialog.setHeaderText("Select Payment Method");

        ButtonType cashButton = new ButtonType("Cash", ButtonBar.ButtonData.OK_DONE);
        ButtonType cardButton = new ButtonType("Credit Card", ButtonBar.ButtonData.OK_DONE);

        dialog.getDialogPane().getButtonTypes().addAll(cashButton, cardButton, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == cashButton)
                return "Cash";
            if (button == cardButton)
                return "Credit Card";
            return null;
        });

        dialog.showAndWait().ifPresent(paymentMethod -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Payment Successful");
            alert.setHeaderText("Payment Completed");
            alert.setContentText("Payment: " + paymentMethod + "\n\nItems Purchased:\n"
                    + String.join("\n", cart.getItems()) + "\n\nTotal Paid: " + cart.getTotal() + " บาท");
            alert.showAndWait();
            cart.clearCart();
            updateCartDisplay();
        });
    }

    private void showReviewDialog() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Review Restaurant");
        dialog.setHeaderText("Leave a Review");

        VBox vbox = new VBox();
        TextArea reviewText = new TextArea();
        reviewText.setPromptText("Write your review here...");

        Label ratingLabel = new Label("Rate the restaurant (1-5):");
        ChoiceBox<Integer> ratingBox = new ChoiceBox<>();
        ratingBox.getItems().addAll(1, 2, 3, 4, 5);
        ratingBox.setValue(5);

        vbox.getChildren().addAll(ratingLabel, ratingBox, reviewText);

        ButtonType submitButton = new ButtonType("Submit", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().setContent(vbox);
        dialog.getDialogPane().getButtonTypes().addAll(submitButton, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == submitButton) {
                return "Rating: " + ratingBox.getValue() + "\nReview: " + reviewText.getText();
            }
            return null;
        });

        dialog.showAndWait().ifPresent(review -> {
            reviews.add(review);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Review Submitted");
            alert.setHeaderText("Thank you for your feedback!");
            alert.setContentText("Your review: \n" + review);
            alert.showAndWait();
        });
    }

    private void showReviewHistory() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Review History");
        alert.setHeaderText("Previous Reviews");
        alert.setContentText(String.join("\n\n", reviews));
        alert.showAndWait();
    }

    private void goToNameMenu(Stage primaryStage) {
        new WelcomeUI(primaryStage);
    }

    public Scene getScene() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getScene'");
    }
}
