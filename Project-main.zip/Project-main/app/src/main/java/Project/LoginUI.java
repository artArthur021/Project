package Project;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginUI {
    public LoginUI(Stage primaryStage) {
        VBox root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-background-color:rgb(255, 255, 255);");
        
        Label titleLabel = new Label("Login to Your Account");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");
        
        Button loginButton = new Button("Login");
        Button registerButton = new Button("Register");
        Label messageLabel = new Label();
        
        loginButton.setStyle("-fx-background-color:rgb(1, 17, 1); -fx-text-fill: white;");
        registerButton.setStyle("-fx-background-color:rgb(0, 0, 0); -fx-text-fill: white;");
        
        loginButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();
        
            System.out.println("Input Username: " + username);
            System.out.println("Input Password: " + password);
            User a = Database.authenticate(username, password);
            if (a != null) {
                System.out.println("Login Successful");
                new WelcomeUI(primaryStage); // เปลี่ยนหน้าไป WelcomeUI
            } else {
                System.out.println("Login Failed");
                messageLabel.setText("Invalid username or password");
                messageLabel.setStyle("-fx-text-fill: red;");
            }
        });
        
        

        registerButton.setOnAction(e -> new RegisterUI(primaryStage));

        root.getChildren().addAll(titleLabel, usernameField, passwordField, loginButton, registerButton, messageLabel);

        primaryStage.setScene(new Scene(root, 350, 250));
        primaryStage.setTitle("Login UI");
        primaryStage.show();
    }

    private boolean authenticate(String username, String password) {
        return "admin".equals(username.trim()) && "password".equals(password.trim());
    }
    
    
}
